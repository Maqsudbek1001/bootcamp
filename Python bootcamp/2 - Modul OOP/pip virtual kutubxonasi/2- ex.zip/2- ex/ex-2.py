import requests
name = requests.__version__
print(name)


