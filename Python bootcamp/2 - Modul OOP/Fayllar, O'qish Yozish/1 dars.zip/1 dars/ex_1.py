
with open("file.txt", "w") as file:
    file.write("Hello Files")
